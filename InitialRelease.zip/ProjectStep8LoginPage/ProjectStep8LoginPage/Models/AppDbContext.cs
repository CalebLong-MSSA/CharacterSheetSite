﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProjectStep8LoginPage.Models
{
   public class AppDbContext : DbContext
   {
      // F I E L D S  &  P R O P E R T I E S

      public DbSet<User> Users { get; set; }

      public DbSet<Inventory> Inventories { get; set; }

      public DbSet<Character> Characters { get; set; }

      // C O N S T R U C T O R S

      public AppDbContext(DbContextOptions<AppDbContext> options)
         : base(options)
      {

      }

      // M E T H O D S

      protected override void OnModelCreating(ModelBuilder modelBuilder)
      {
         base.OnModelCreating(modelBuilder);

         modelBuilder.Entity<User>()
                     .HasIndex(u => u.Email)
                     .IsUnique();

         modelBuilder.Entity<Character>().HasData
            (new Character
            {
               CharId = 1,
               Name = "Test Mansley",
               Strength = 17,
               Dexterity = 13,
               Constitution = 18,
               Wisdom = 10,
               Intelligence = 10,
               Charisma = 17,
               Race = "Human",
               PlayerClass = "Warrior",
               Alignment = "True Neutral",
               UserId = 1
            }
            );

         modelBuilder.Entity<Character>().HasData
            (new Character
            {
               CharId = 2,
               Name = "Test Mansley II",
               Strength = 12,
               Dexterity = 16,
               Constitution = 11,
               Wisdom = 19,
               Intelligence = 13,
               Charisma = 14,
               Race = "Lizard",
               PlayerClass = "Wizard",
               Alignment = "Chaotic Evil",
               UserId = 1
            }
            );
      }
   }
}
