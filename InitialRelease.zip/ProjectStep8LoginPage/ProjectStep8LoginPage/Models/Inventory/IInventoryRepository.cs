﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProjectStep8LoginPage.Models
{
   public interface IInventoryRepository
   {
      public IQueryable<Inventory> GetAllInventories();
   }
}
