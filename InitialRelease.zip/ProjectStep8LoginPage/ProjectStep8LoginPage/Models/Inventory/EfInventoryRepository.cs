﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProjectStep8LoginPage.Models
{
   public class EfInventoryRepository : IInventoryRepository
   {
      // F I E L D S  &  P R O P E R T I E S

      private AppDbContext _context;


      // C O N S T R U C T O R S

      public EfInventoryRepository(AppDbContext context)
      {
         _context = context;
      }

      // M E T H O D S

      public IQueryable<Inventory> GetAllInventories()
      {
         return _context.Inventories;
      }
   }
}
