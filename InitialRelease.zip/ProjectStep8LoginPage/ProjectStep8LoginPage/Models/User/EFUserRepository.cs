﻿using Microsoft.AspNetCore.Http;
using System;
using System.Linq;
using System.Security.Cryptography;
using System.Text;

namespace ProjectStep8LoginPage.Models
{
   public class EFUserRepository : IUserRepository
   {
      // Fields and Properties

      private AppDbContext _context;
      private ISession _session;

      // Constructors

      public EFUserRepository(AppDbContext context, IHttpContextAccessor alpha)
      {
         _context = context;
         _session = alpha.HttpContext.Session;
      }

      // Create

      public User AddUser(User u)
      {
         try
         {
            u.Password = encrypt(u.Password);
            _context.Users.Add(u);
            _context.SaveChanges();
         }
         catch (Exception bravo)
         {
            u.UserId = -1;
         }
         u.Password = "";
         return u;
      }

      // Read

      public IQueryable<User> GetAllUsers()
      {
         return _context.Users;
      }

      public User GetUserByEmail(string userEmail)
      {
         User u = _context.Users.FirstOrDefault(u => u.Email == userEmail);
         return u;
      }

      public User GetUserById(int uId)
      {
         return _context.Users.Find(uId);
      }

      public User GetUserBySession()
      {
         User u = _context.Users.Where(u => u.UserId == _session.GetInt32("userId")).FirstOrDefault();
         return u;
      }

      //  L O G I N

      public bool Login(User u)
      {
         User dbUser = GetUserByEmail(u.Email);

         if (dbUser == null)
         {
            return false;
         }

         u.Password = encrypt(u.Password);

         if (dbUser.Password == u.Password)
         {
            _session.SetInt32("userId", dbUser.UserId);
            _session.SetString("userEmail", dbUser.Email);
            if (dbUser.IsAdmin == true)
            {
               _session.SetInt32("userAdmin", 1);
            }
            else
            {
               _session.SetInt32("userAdmin", 0);
            }
            return true;
         }

         return false;
      }


      // VIM time

      public bool IsUserLoggedIn()
      {
         int? userId = _session.GetInt32("userId");
         if (userId == null)
         {
            return false;
         }
         else
         {
            return true;
         }
      }

      public int GetLoggedInUserId()
      {
         int? userId = _session.GetInt32("userId");
         if (userId == null)
         {
            return -1;
         }
         else
         {
            return userId.Value;
         }
      }



      // Update
      public User UpdateUser(User u)
      {
         throw new NotImplementedException();
      }


      // Delete

      public bool DeleteUser(int userId)
      {
         throw new NotImplementedException();
      }

      public bool DeleteUser(string userEmail)
      {
         throw new NotImplementedException();
      }

      public string GetLoggedInUserEmail()
      {
         return _session.GetString("userEmail");
      }

      public bool IsUserAdmin()
      {
         if (_session.GetInt32("userAdmin") == 1)
         {
            return true;
         }
         return false;
      }

      public void Logout()
      {
         _session.Remove("userEmail");
         _session.Remove("userId");
         _session.Remove("userAdmin");
      }


      // Password Encryption
      private string encrypt(string password)
      {
         SHA256 myHashingVar = SHA256.Create();
         byte[] passwordByteArray = Encoding.ASCII.GetBytes(password);
         passwordByteArray[0] += 1;
         passwordByteArray[1] += 2;
         passwordByteArray[2] += 3;
         passwordByteArray[3] += 4;
         byte[] hashedPasswordByteArray = myHashingVar.ComputeHash(passwordByteArray);
         string hashedPassword = "";
         foreach (byte b in hashedPasswordByteArray)
         {
            hashedPassword += b.ToString("x2");
         }
         return hashedPassword;
      }
   }
}
