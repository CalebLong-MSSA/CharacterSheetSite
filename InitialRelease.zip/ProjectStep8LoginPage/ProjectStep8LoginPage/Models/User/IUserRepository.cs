﻿using System.Linq;

namespace ProjectStep8LoginPage.Models
{
   public interface IUserRepository
   {
      // Create

      public User AddUser(User u);

      // Read
      public IQueryable<User> GetAllUsers();
      public string GetLoggedInUserEmail();
      public int GetLoggedInUserId();
      public User GetUserByEmail(string userEmail);
      public User GetUserById(int userId);
      public User GetUserBySession();
      public bool IsUserAdmin();
      public bool IsUserLoggedIn();
      public bool Login(User u);
      public void Logout();

      // Update
      public User UpdateUser(User u);

      // Delete
      public bool DeleteUser(int userId);
      public bool DeleteUser(string userEmail);
   }
}
