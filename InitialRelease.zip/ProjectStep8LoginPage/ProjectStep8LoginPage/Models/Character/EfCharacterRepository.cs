﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProjectStep8LoginPage.Models
{
   public class EfCharacterRepository : ICharacterRepository
   {
      //   F i e l d s   &   M e t h o d s

      private AppDbContext _context;
      private IUserRepository _userRepository;

      //   C o n s t r u c t o r s

      public EfCharacterRepository(AppDbContext context, IUserRepository userRepository)
      {
         _context = context;
         _userRepository = userRepository;
      }

      //   M e t h o d s

      //   C r e a t e

      public Character CreateCharacter(Character c)
      {
         if (c == null)
         {
            return null;
         }

         User u = _userRepository.GetUserById(c.UserId);
         if (u == null)
         {
            return null;
         }

         _context.Characters.Add(c);
         _context.SaveChanges();
         return c;
      }

      //   R e a d

      public Character GetCharacterById(int charId)
      {
         //return _context.Characters.Find(charId);
         return _context.Characters.Where(c => c.CharId == charId).FirstOrDefault();
      }

      public Character GetCharacterByName(string charName)
      {
         return _context.Characters.Where(c => c.Name == charName).FirstOrDefault();
      }

      public IQueryable<Character> GetAllCharacters()
      {
         return _context.Characters.Where(c => c.UserId == _userRepository.GetLoggedInUserId()); // Go get current logged in user out of session
      }

      //   U p d a t e
      #region "Update Methods"
      public Character UpdateCharacter(Character c)
      {
         if (c == null)
         {
            return null;
         }

         Character charToUpdate = _context.Characters.Find(c.CharId);
         if (charToUpdate != null)
         {
            charToUpdate.Name = c.Name;
            charToUpdate.Strength = c.Strength;
            charToUpdate.Dexterity = c.Dexterity;
            charToUpdate.Constitution = c.Constitution;
            charToUpdate.Wisdom = c.Wisdom;
            charToUpdate.Intelligence = c.Intelligence;
            charToUpdate.Charisma = c.Charisma;
            charToUpdate.PlayerClass = c.PlayerClass;
            charToUpdate.Alignment = c.Alignment;
            charToUpdate.Race = c.Race;
            _context.SaveChanges();
         }
         return charToUpdate;
      }
      #endregion


      //   D e l e t e
      #region "Delete Methods"
      public bool DeleteCharacter(int charId)
      {
         Character c = _context.Characters.Find(charId);
         if (c == null)
         {
            return false;
         }
         _context.Characters.Remove(c);
         _context.SaveChanges();
         return true;
      }
      #endregion
   }
}
