﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProjectStep8LoginPage.Models
{
   public interface ICharacterRepository
   {
      public Character CreateCharacter(Character c);

      //   R e a d

      public Character GetCharacterByName(string charName);
      public Character GetCharacterById(int charId);
      public IQueryable<Character> GetAllCharacters();


      //   U p d a t e

      public Character UpdateCharacter(Character c);

      //   D e l e t e

      public bool DeleteCharacter(int charId);
   }
}
