﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace ProjectStep8LoginPage.Models
{
   [Table("Character")]
   public class Character
   { 
      [Key]
      public int CharId { get; set; }

      [Required(ErrorMessage = "Must have a name.")]
      public string Name  { get; set; }

      [Required(ErrorMessage = "Required stat.")]
      public int Strength { get; set; }

      [Required(ErrorMessage = "Required stat.")]
      public int Dexterity { get; set; }

      [Required(ErrorMessage = "Required stat.")]
      public int Constitution { get; set; }

      [Required(ErrorMessage = "Required stat.")]
      public int Intelligence { get; set; }

      [Required(ErrorMessage = "Required stat.")]
      public int Wisdom { get; set; }

      [Required(ErrorMessage = "Required stat.")]
      public int Charisma { get; set; }
      public string Race { get; set; } = "";
      public string PlayerClass { get; set; } = "";
      public string Alignment { get; set; } = "";

      [ForeignKey("User")]
      public int UserId { get; set; } //Future, ? behind int to have template characters
   }
}

