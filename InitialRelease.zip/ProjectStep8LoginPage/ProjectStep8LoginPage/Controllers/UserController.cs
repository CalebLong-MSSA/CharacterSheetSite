﻿using Microsoft.AspNetCore.Mvc;
using ProjectStep8LoginPage.Models;

namespace ProjectStep8LoginPage.Controllers
{
   public class UserController : Controller
   {
      //   F i e l d s   &   P r o p e r t i e s

      private IUserRepository _repository;

      //   C o n s t r u c t o r s

      public UserController(IUserRepository repository)
      {
         _repository = repository;
      }

      //   M e t h o d s

      //   C r e a t e

      [HttpGet]
      public IActionResult Register()
      {
         return View();
      }

      [HttpPost]
      public IActionResult Register(User u)
      {
         _repository.AddUser(u);
         if (u.UserId < 1)
         {
            return View(u);
         }

         return RedirectToAction("Login");
      }

      //   R e a d

      public IActionResult Index()
      {
         return View("Index", "Home");
      }

      [HttpGet]
      public IActionResult Login()
      {
         return View();
      }

      [HttpPost]
      public IActionResult Login(User u)
      {
         bool validUser = _repository.Login(u);
         if (validUser == true)
         {
            return RedirectToAction("Index", "Home"); // FIX IT
         }
         return View(u);
      }

      public IActionResult Logout()
      {
         _repository.Logout();
         return RedirectToAction("Index", "Home"); // FIX THIS NOW
      }

      //   U p d a t e

      //   D e l e t e
   }
}
