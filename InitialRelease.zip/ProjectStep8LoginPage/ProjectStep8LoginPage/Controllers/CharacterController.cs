﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using ProjectStep8LoginPage.Models;

namespace ProjectStep8LoginPage.Controllers
{
   public class CharacterController : Controller
   {
      //   F i e l d s   &   P r o p e r t i e s

      private ICharacterRepository _repository;
      private IUserRepository _userRepository;

      //   C o n s t r u c t o r

      public CharacterController(ICharacterRepository repository, IUserRepository userRepository)
      {
         _repository = repository;
         _userRepository = userRepository;
      }

      //   M e t h o d s

      //   C r e a t e

      [HttpGet]
      public IActionResult Create()
      {
         User u = _userRepository.GetUserBySession();
         Character c = new Character();
         c.UserId = u.UserId;
         return View(c);
      }

      [HttpPost]
      public IActionResult Create(Character c)
      {
         if (ModelState.IsValid)
         {
            _repository.CreateCharacter(c);
            //return RedirectToAction("Detail", new { CharId = c.CharId });
            return RedirectToAction("Index");
         }
         return View(c);
      }

      //   R e a d

      public IActionResult Index()
      {
         IQueryable<Character> allCharacters = _repository.GetAllCharacters();

         return View(allCharacters);
      }

      public IActionResult Detail(int charId)
      {
         Character character = _repository.GetCharacterById(charId);
         return View(character);
      }

      //   U p d a t e

      [HttpGet]
      public IActionResult Update(int charId)
      {
         Character c = _repository.GetCharacterById(charId);
         return View(c);
      }

      [HttpPost]
      public IActionResult Update(Character updatedCharacter)
      {
         if (ModelState.IsValid)
         {
            _repository.UpdateCharacter(updatedCharacter);
            return RedirectToAction("Detail", new { charId = updatedCharacter.CharId });
         }
         return View(updatedCharacter);
      }

      //   D e l e t e

      [HttpGet]
      public IActionResult Delete(int charId)
      {
         Character character = _repository.GetCharacterById(charId);
         return View(character);
         //if (c == null)
         //{
         //   return RedirectToAction("Index", "Home");
         //}
         //return View(c);
      }

      [HttpPost]
      public IActionResult Delete(Character c)
      {
         _repository.DeleteCharacter(c.CharId);
         //return RedirectToAction("Detail", "Character", new { UserId = c.UserId });
         return RedirectToAction("Index");
      }
   }
}
